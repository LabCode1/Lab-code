import tkinter as tk
from tkinter import messagebox
import sqlite3

def create_experiment():
    code = code_entry.get()
    desc = desc_entry.get()
    conn = sqlite3.connect('labcode.db')
    c = conn.cursor()
    c.execute("INSERT INTO experiments (code, description) VALUES (?, ?)", (code, desc))
    conn.commit()
    conn.close()
    messagebox.showinfo("تم", "تمت إضافة التجربة")
    code_entry.delete(0, tk.END)
    desc_entry.delete(0, tk.END)

root = tk.Tk()
root.title("واجهة المعلم - LabCode")
tk.Label(root, text="كود التجربة:").pack(pady=5)
code_entry = tk.Entry(root)
code_entry.pack(pady=5)
tk.Label(root, text="وصف التجربة:").pack(pady=5)
desc_entry = tk.Entry(root)
desc_entry.pack(pady=5)
tk.Button(root, text="إضافة التجربة", command=create_experiment).pack(pady=10)
root.mainloop()
