import tkinter as tk
from tkinter import messagebox
import sqlite3
import time

def submit_code():
    code = code_entry.get()
    conn = sqlite3.connect('labcode.db')
    c = conn.cursor()
    c.execute("SELECT * FROM experiments WHERE code=?", (code,))
    result = c.fetchone()
    if result:
        start_time = time.time()
        messagebox.showinfo("التجربة", f"ابدأ تنفيذ التجربة: {result[2]}")
        # تجربة بسيطة: سؤال برمجي
        answer = input("اكتب ناتج 2 + 2: ")
        end_time = time.time()
        duration = round(end_time - start_time, 2)
        correct = (answer.strip() == "4")
        c.execute("INSERT INTO results (code, student, duration, correct) VALUES (?, ?, ?, ?)", 
                  (code, "طالب1", duration, correct))
        conn.commit()
        messagebox.showinfo("النتيجة", f"تم حفظ النتيجة. الوقت: {duration} ثانية")
    else:
        messagebox.showerror("خطأ", "الكود غير صحيح")
    conn.close()

root = tk.Tk()
root.title("واجهة الطالب - LabCode")
tk.Label(root, text="أدخل كود التجربة:").pack(pady=10)
code_entry = tk.Entry(root)
code_entry.pack(pady=5)
tk.Button(root, text="بدء التجربة", command=submit_code).pack(pady=20)
root.mainloop()
