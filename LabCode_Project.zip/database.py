import sqlite3

conn = sqlite3.connect('labcode.db')
c = conn.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS experiments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    description TEXT
)""")
c.execute("""CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT,
    student TEXT,
    duration REAL,
    correct BOOLEAN
)""")
conn.commit()
conn.close()
print("تم تهيئة قاعدة البيانات.")
